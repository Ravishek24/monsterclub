<template>
    <h1>risk</h1>
      </template>
      
      <script>
      export default {
        name: 'RiskAgreement',
        props: {
          msg: String
        }
      }
      </script>
      
      <!-- Add "scoped" attribute to limit CSS to this component only -->
      <style scoped>
      
      </style>
      