<template>
  <div class="mainguide">
    <div class="gamstat-navbar mainguide-navbar">
      <div class="gamestat-navbar-fixed mainguide">
        <div class="gamstat-navbar-content mainguide">
          <div class="gamstat-content-left mainguide">
            <i class='bx bx-chevron-left mainguide'></i>
          </div>
          <div class="gamstat-content-center mainguide">Beginner's Guide</div>
          <div class="gamstat-content-right mainguide"></div>
        </div>
      </div>
    </div>
     <div class="mainguide-container1 mainguide-content">
      <h1>1.How to Register</h1>
      <p>-Fill your phone number</p>
      <p>-Set your own password ( 6 letters )</p>
      <p>-Fill your Recommendation code</p>
      <p>-Click Register</p>
      <img src="../assets/mainguide1.jpg" alt="">
    </div>

    <div class="mainguide-container2 mainguide-content">
      <h1>2. How to betting</h1>
      <p>Click start game then choose 1minute, 3minute, 5minute or 10minute.</p>
      <p>Green : if the result shows 1,3,7,9</p>
      <p>Red  : if the result shows 2,4,6,8</p>
      <p>Violet : if the result shows 0 or 5</p>
      <p>Small : if the result shows 0,1,2,3,4</p>
      <p>Big  : if the result shows 5,6,7,8,9</p>
      <p>This company not allowed to place Illegal betting <br>
        Exp ：Betting (Big and small together) or (Red and Green together) in the same time.</p>
      <img src="../assets/mainguide2.png" alt="">
    </div>

    <div class="mainguide-container3 mainguide-content">
      <h1>3.How to recharge</h1>
      <p>Click Wallet Icon, Click The Recharge Button, and we have three ways to make a recharge ( UPI, BANK TRANSFER, USDT/CRYPTO)</p>
     
      <img src="../assets/mainguide3.png" alt="">
      <img src="../assets/mainguide4.png" alt="">
    </div>

    <div class="mainguide-container4 mainguide-content">
      <h1>4. How to Withdraw</h1>
      <p>Click Wallet Icon, Click Withdraw Button.</p>
      <p>- Enter withdraw amount</p>
      <p>- Make Sure Your Total Bet Until Zero</p>
      <p>- Select Your Bank Account Or Add Your Bank Account</p>
      <p>- Input Your Login Password</p>
      
      <img src="../assets/mainguide5.png" alt="">
      <img src="../assets/mainguide6.png" alt="">
    </div>

    <div class="mainguide-container5 mainguide-content">
      <h1>5. Orders</h1>
      <p>When The Batting Complete You Can Click My Game Record To See Your Bet Record, You Can Check The Chart Trend</p>
      <img src="../assets/mainguide7.png" alt="">
    </div>

    <div class="mainguide-container2 mainguide-content">
      <h1>6. Promotion</h1>
      <p>If you have a downline or referral member use your own link to register and if they make a recharge you can claim a reward. The agent will get a minimum commission of 0.6 % (level 1) and 0.18% (level 2) from each transaction that is done by the referral (Added every day at 00:30 AM.) If the accumulated transactions of the Referral reach a certain target, the agent will get an additional bonus with the following rebates.</p>
      <img src="../assets/mainguide8.png" alt="">
      <img src="../assets/mainguide9.png" alt="">
    </div>

    <div class="mainguide-container1 mainguide-content">
      <h1>9. Forgot Password</h1>
      <p>- Click Forgot Password</p>
      <p>-Fill your mobile number</p>
      <p>-Click OTP then will send it to message to your number as your verfication code</p>
      <p>-Enter Strongest new password, and Click Submit.</p>
      <p>-If Cannot Receive OTP Please Contact Customer Service Immediately.</p>
      <img src="../assets/mainguide13.png" alt="">
      <img src="../assets/mainguide14.png" alt="">
    </div>

    <div class="mainguide-container1 mainguide-content">
      <h1>7. Account security</h1>
      <p>Go To Center Icon, Click Account Security.</p>
      <p>-Fill your mobile number</p>
      <p>-Click OTP then will send it to message to your number as your verfication code</p>
      <p>-Enter Strongest new password, and Confirm your password.</p>
      <p>Click sure</p>
      <img src="../assets/mainguide11.png" alt="">
      <img src="../assets/mainguide12.png" alt="">
    </div>

    <div class="mainguide-container1 mainguide-content">
      <h1>8. Forgot Password</h1>
      <p>- Click Forgot Password</p>
      <p>-Fill your mobile number</p>
      <p>-Click OTP then will send it to message to your number as your verfication code</p>
      <p>-Enter Strongest new password, and Click Submit.</p>
      <p>-If Cannot Receive OTP Please Contact Customer Service Immediately.</p>
      <img src="../assets/mainguide13.png" alt="">
      <img src="../assets/mainguide14.png" alt="">
      <img src="../assets/mainguide15.png" alt="">
    </div>


    <div class="mainguide-container1 mainguide-content">
      <h1>9. App download</h1>
      <p>Click top right corner download icon, your can download the app and easy to use</p>
      <img src="../assets/mainguide16.png" alt="">
    </div>


    <div class="mainguide-container1 mainguide-content">
      <h1>10. About</h1>
      <p>Click About for more details regarding Privacy Policy and Risk Disclosure Agreement</p>  
      <img src="../assets/mainguide17.png" alt="">
      <img src="../assets/mainguide18.png" alt="">
    </div>
    
  </div>
</template>

<script>
export default {
  name: 'MainGuide',
  props: {
    msg: String
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped></style>
