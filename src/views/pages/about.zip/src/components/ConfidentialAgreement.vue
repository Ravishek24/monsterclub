<template>
   <h1>hello</h1>
     </template>
     
     <script>
     export default {
       name: 'ConfidentialAgreement',
       props: {
         msg: String
       }
     }
     </script>
     
     <!-- Add "scoped" attribute to limit CSS to this component only -->
     <style scoped>
     
     </style>
     