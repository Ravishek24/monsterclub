<?php
// database.php

$host = 'localhost';
$db = 'a29club767ghfghf';
$user = 'a29club767ghfghf';
$pass = 'a29club767ghfghf';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
